# Zomy Bot - Discord Bot Website

## Overview
This project contains a professional, static website for the Zomy Discord bot. The website showcases the bot's features and commands, allowing users to invite the bot to their Discord servers. The site is designed to be completely separate from the bot code and ready for free hosting on platforms like Netlify, Vercel, or GitHub Pages.

## Project Structure
```
├── website/                    # All website files (ready to download and host)
│   ├── index.html             # Main HTML file with all content
│   ├── css/
│   │   └── style.css          # All styling, animations, and responsive design
│   ├── js/
│   │   └── script.js          # Interactive features and smooth scrolling
│   └── README.md              # Detailed hosting instructions
└── attached_assets/           # User-provided files (bot screenshot)
```

## Current State
✅ Website fully built and functional  
✅ All bot commands documented and categorized  
✅ Modern Discord-themed design with animations  
✅ Fully responsive (mobile, tablet, desktop)  
✅ Ready for free hosting deployment  
✅ Comprehensive README with step-by-step hosting instructions  

## Bot Features Showcased
The website documents all Zomy bot commands across 6 categories:
1. **Economy - Basic**: balance, daily, pray, leaderboard
2. **Economy - Gambling**: coinflip, slot
3. **Economy - Earning**: hunt, beg, work, rob
4. **Moderation**: ban, kick, timeout, warn, afk
5. **Giveaways**: gcreate, gedit, gend, greroll, glist
6. **Owner Commands**: addmoney, setmoney, reseteconomy

## Technologies Used
- **HTML5** - Semantic markup
- **CSS3** - Modern styling with animations, gradients, and transitions
- **Vanilla JavaScript** - Smooth scrolling and intersection observer animations
- **Font Awesome** - Icons throughout the site
- **Google Fonts (Poppins)** - Clean, modern typography

## User Instructions
The user needs to:
1. Download the entire `website` folder
2. Update the bot invite link in `index.html` (replace `YOUR_BOT_CLIENT_ID` with their actual Discord bot client ID)
3. Upload to any free hosting platform (Netlify, Vercel, GitHub Pages, Cloudflare Pages)

Detailed step-by-step instructions are provided in `website/README.md`

## Recent Changes (November 9, 2025)
- Created complete website structure with clean folder organization
- Built responsive HTML page with hero section, features, commands, and invite sections
- Designed modern CSS with Discord theme (blurple colors), gradients, and smooth animations
- Added JavaScript for smooth scrolling, fade-in animations, and interactive elements
- Set up workflow for local preview using http-server
- Created comprehensive README with hosting instructions for multiple free platforms

## User Preferences
- User wants website files completely separated from bot code for easy download
- User plans to host website for free (not on Replit)
- User has a Discord moderation bot with economy, gambling, and giveaway features
- Bot uses both prefix commands (! and Zomy) and slash commands
