# Zomy Bot Website

A professional, modern website for the Zomy Discord bot. This static website showcases all bot features and commands, allowing users to invite the bot to their Discord servers.

## 📁 What's Inside

This folder contains all the files needed to host your bot's website:

```
website/
├── index.html          # Main website page
├── css/
│   └── style.css      # All styling and animations
├── js/
│   └── script.js      # Interactive features
└── README.md          # This file
```

## 🚀 How to Download & Host for FREE

### Step 1: Download All Files

Download the entire `website` folder from this Replit project. You need all files:
- `index.html`
- `css/style.css`
- `js/script.js`

### Step 2: Update Bot Invite Link

Before hosting, you **MUST** update your bot's invite link:

1. Open `index.html` in any text editor
2. Find this line (around line 264):
   ```html
   <a href="https://discord.com/api/oauth2/authorize?client_id=YOUR_BOT_CLIENT_ID&permissions=8&scope=bot%20applications.commands"
   ```
3. Replace `YOUR_BOT_CLIENT_ID` with your actual Discord bot's client ID
   - Find your client ID in the [Discord Developer Portal](https://discord.com/developers/applications)
   - Go to your bot → OAuth2 → Copy the Client ID

### Step 3: Choose a FREE Hosting Platform

Here are the best free hosting options for static websites:

#### Option A: Netlify (Recommended - Easiest)
1. Go to [netlify.com](https://www.netlify.com/)
2. Sign up for free
3. Drag and drop the `website` folder
4. Done! Your site is live with a free URL
5. Optional: Add a custom domain

#### Option B: Vercel
1. Go to [vercel.com](https://vercel.com/)
2. Sign up for free
3. Click "New Project"
4. Upload the `website` folder
5. Deploy! Get a free URL instantly

#### Option C: GitHub Pages
1. Create a GitHub account (free)
2. Create a new repository
3. Upload all files from the `website` folder
4. Go to Settings → Pages
5. Enable Pages and select the main branch
6. Your site will be live at `yourusername.github.io/repository-name`

#### Option D: Cloudflare Pages
1. Go to [pages.cloudflare.com](https://pages.cloudflare.com/)
2. Sign up for free
3. Create a new project
4. Upload the `website` folder
5. Deploy and get a free URL

## 🎨 Features

✅ Modern, professional design with Discord theme  
✅ Fully responsive (works on mobile, tablet, desktop)  
✅ Smooth animations and hover effects  
✅ Complete command documentation organized by category  
✅ Ready-to-use bot invite button  
✅ No dependencies - pure HTML, CSS, JavaScript  
✅ Fast loading and SEO optimized  

## 📱 What It Includes

### Pages & Sections:
1. **Hero Section** - Eye-catching introduction with bot stats
2. **Features** - 6 feature cards highlighting bot capabilities
3. **Commands** - Complete documentation of all bot commands:
   - Economy Commands (Basic, Gambling, Earning)
   - Moderation Commands
   - Giveaway Commands
   - Owner Commands
4. **Invite Section** - Large call-to-action to add bot
5. **Footer** - Navigation and branding

### Command Categories Documented:
- 💰 Economy Commands - Basic (balance, daily, pray, leaderboard)
- 🎲 Economy Commands - Gambling (coinflip, slot)
- 💼 Economy Commands - Earning (hunt, beg, work, rob)
- 🛡️ Moderation Commands (ban, kick, timeout, warn, afk)
- 🎁 Giveaway Commands (gcreate, gedit, gend, greroll, glist)
- 👑 Owner Commands (addmoney, setmoney, reseteconomy)

## ⚙️ Customization Tips

Want to customize the website? Here's what you can easily change:

### Update Bot Stats (in `index.html`):
```html
<div class="stats">
    <h3>50+</h3> <!-- Change server count -->
    <h3>10K+</h3> <!-- Change user count -->
    <h3>40+</h3> <!-- Change command count -->
</div>
```

### Change Colors (in `css/style.css`):
```css
:root {
    --discord-blurple: #5865F2;  /* Main accent color */
    --discord-dark: #2C2F33;     /* Background color */
}
```

### Add More Commands:
Simply copy the `command-item` structure in `index.html` and add your new commands!

## 🔧 Testing Locally

Want to preview before hosting?

**With Python (if installed):**
```bash
cd website
python -m http.server 8000
```
Then open `http://localhost:8000`

**With Node.js (if installed):**
```bash
cd website
npx http-server -p 8000
```
Then open `http://localhost:8000`

## 📝 Important Notes

1. **Update the invite link** with your real bot client ID before hosting!
2. All files must stay in the same folder structure
3. Don't rename files unless you update the references
4. The website is 100% static - no server or database needed
5. It's completely free to host on any of the platforms listed above

## 🆘 Need Help?

- **Bot invite link not working?** Make sure you replaced `YOUR_BOT_CLIENT_ID` with your actual client ID
- **Website not loading?** Check that all files are in the correct folder structure
- **Styling broken?** Ensure `css/style.css` path is correct
- **JavaScript not working?** Verify `js/script.js` is in the right location

## 📄 License

This website template is free to use for your Discord bot. Feel free to customize it however you like!

---

**Enjoy your new website! 🎉**

If you need to make changes, just edit the HTML, CSS, or JavaScript files and re-upload to your hosting platform.
